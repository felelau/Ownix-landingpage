
let airdropClaimed = false;

export function claimAirdrop() {
  if (airdropClaimed) return { success: false, message: 'Airdrop sudah diklaim' };
  airdropClaimed = true;
  return { success: true, amount: 100, message: 'Berhasil klaim 100 ONX' };
}

export function checkAirdropStatus() {
  return airdropClaimed;
}
