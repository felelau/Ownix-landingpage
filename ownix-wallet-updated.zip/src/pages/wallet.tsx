
import { useWallet } from '../context/WalletContext';
import { generateWallet } from '../utils/wallet';

export default function WalletPage() {
  const { setWallet } = useWallet();

  const handleGenerate = () => {
    const newWallet = generateWallet();
    setWallet(newWallet);
    alert('Wallet berhasil dibuat!');
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Buat Wallet Baru</h1>
      <button onClick={handleGenerate} className="bg-blue-500 text-white px-4 py-2 rounded">
        Generate Wallet
      </button>
    </div>
  );
}
