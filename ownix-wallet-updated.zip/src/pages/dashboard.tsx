
import { useWallet } from '../context/WalletContext';
import { claimAirdrop, checkAirdropStatus } from '../utils/airdrop';
import { useState } from 'react';

export default function Dashboard() {
  const { wallet, balance, setBalance } = useWallet();
  const [airdropMsg, setAirdropMsg] = useState('');

  const handleAirdrop = () => {
    const result = claimAirdrop();
    if (result.success) {
      setBalance(balance + result.amount);
    }
    setAirdropMsg(result.message);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Dashboard Wallet</h1>
      {wallet ? (
        <>
          <p className="mb-2"><strong>Public Key:</strong></p>
          <pre className="bg-gray-200 p-2 overflow-x-auto">{wallet.publicKey}</pre>
          <p className="mt-4">💰 Saldo: {balance} ONX</p>
          <button onClick={handleAirdrop} className="mt-4 bg-green-500 text-white px-4 py-2 rounded">
            Klaim Airdrop
          </button>
          <p className="mt-2 text-sm text-gray-700">{airdropMsg}</p>
        </>
      ) : (
        <p>Silakan buat wallet terlebih dahulu.</p>
      )}
    </div>
  );
}
